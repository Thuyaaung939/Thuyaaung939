// This class was generated on Tue, 21 May 2019 11:25:19 PDT by version 0.1.0-dev+8fcb5f of Braintree SDK Generator
// ShippingDetail.cs
// @version 0.1.0-dev+8fcb5f
// @type object
// @data H4sIAAAAAAAC/8xa23LbRtK+/5+iS/+F4yoeIimHv1yVC0WyEyexo7LkpP7yusQG0CS6NJiBZwak4K1c5AH2QfZ2XyHZ99rqGYAgSEg+ROHmjpxjd8/X01/34O8Hl3VJB48OXM5lyXpxlZFHVgejg5/QMiaKnmMxPOB7qpu+g9HBGbnUcunZ6INHB5c5QTsB4gQ3ORgdnFiLddzx09HBC8LsR63qg0dzVI6k4U3FlrJ1w7k1JVnP5A4evVrLillmybmr0lgvEu4KOzCik7bpHBS6nQCsPVmN0oUKSuM8KmhmTuAZlg68gVcnseUnVJyFwc/IY4YeX3+Se1+6R9Ppgn1eJZPUFNOFMQtFfPh/eqo4aVZjXVZ+uuJrnt662kNAncG3l89+gM8nh/DqpPJmzkqJeefGFpAa7a1R7hH4nAArb1JTlIo8AXpvOak8dSKtVqvJ6nhi7GJ6+WKa+0J9fjh1lI5lLTeRhv/FbovQPG63GPucxps7jNc7PLy/M25MAWcRPLcfcbYesHPCG327J62NHq9PG7OMm6Nu5raoBZ+jB7QEzhTkuSAHmiijTAwPwQaMOqURWHbXIzAWjM/JgktJo2XjYJWTJZizpvHCIuv1HqzFsuGkoeBF7iGhZvUJPDe+g+OKfS6bFUaDz9lmUKL1dYCFKUmDM5VNaQIvKKt0htq3U8LOpDI3+Vv16afHaWKn4Qc9MRboBuUMRzDb9phJ26BY09XhDNhB5SpUqgYUSRKO3gFm3s1uXd15S+SvdFUkZGcjmLUNWNBsFKRum3xd0uz+cOO8Zb3YhUtSscrk+hIRemDZ7ulD5QSkOQNl0qBuAwhLpSVH2rvgcKWlgh1N4OXaRO2yYb6gIhoDAmiUorQ1XjvQxRPD9pj78ybQO694lqnJKB7mqcUlafjWVC62pNOu849aV1dK/TJ6p4kzUrwkW185sktO+1Ye6Nz1yXYQNIMmcG6cBzOfc0qQmJsRJLhoLBJcrdzoF4PtSdUNOPe07LcPxMTQHyWF7yrnYXZmK1vPgHXzE35A/ccd4gP1CAYd1KTtuV2XCM+9yit3xpC0Tfutskr/liOJ21Q0gsRUipZosxFYg1kAF92Ik7sV1vtSr0qu2uugr1+/Y1fBOVvnx8ZmZIG0Z19DQsqsAJv7a30dGbu+ywavMlcl44HrzLFeKOqWkbtKItkHXGYTOEUtEQ5hrtCPwHlj6xHMlTFWzG6KYHaU0FaQ9vdi9dfvYfd+rBukEuuuW2wPMkAsEPhXyxN7UOsCQITjVvfs8Mtj2LwCoFUuMA2hgXK0Ngb9jniEv8I9IM0pvRZ2KheL0DXhGiLPvFIded0PlHt2O7rdpEfD/kqp0dl72NRV7KkHmv1eSD1djm9X83hQzcjkBrQcAc/XRLB/X7V3WWTfQWOBx9cW37IaQca28UZPN+JjVZoDOphpuvGSsvyMqkDrZ9HVQKHOCrTXEoBQw1OdMeq9Y6VgfYWWcMf5eh27Bsx5kZM4Hy1Jhasr4yU7Ub+5nCrxmBGsck7zPoctrVlyIO7Oo6dgj6cXP46PD7/4Ynwki7VrhSMoMBq6SQVbqrLtxKcns+CQ2niYnaLiubGacTaBn1CFQFN3UrF7FMlapSJTi/8Ux38vv5/ASRxdN+x92vZtjbyQkUGPuweeosYMZXCr/t3jv8MSdRxOc0p9Zd8x4WLF/i1ZgZVMu0btjR6eMm213jvKjm5D2dEA/0/Z1yPwZqUDRJasFC5oAhcFKkVWgqiWDGi9SADj1eFs/95zfJtexwN6ibcIE1BBP1cllU1GoIkXeWJsbkwkQRnLxql/p8JHLcbfBet4VU3gotkyQbbWhM02d78bZ+GiCmusldiStqPavTybXfBNVCusHeASWYUMO6m8XK63rAdpS11ifiKmAFH+rwbtz26DwGfDVZDeca8C//2QQz+eyfCZ8NPWbO8Lg1huC5epM9YLqZSUNVyy31RktaNIdQrUNTyxpNMcPFnL3lgm18W2pu+bilHj3bCJfK0txFAGQSPRFj0vKQYSJ8HjNGf91zjdJlxciXV6p7vVsXu6r/zKjNMcLaaeQnSDEN0Og6VffzLNTOqmrD0tbPCOaaQPU0vOT5vlxzLWTR/GbIEzSS/mTDFbaMYICCwteH3VJ8qk128q42nTcM5boxex5bnx1OBjutkOlxvLdoCwhB6+thw4LbudAsg3X++UPdZxeHvsy+8Hxgo1oAwaxuxNOY6kIjOFbCn3iAuiBDM0AkqGRGHC7PRotit2ABGsjFXZips2IW5ow51T6aaoqiiD0nJK8Mnpy/OHUJDPxSET1NeQBq8MpN8a58ZJTPO8Re0wcL22tjfdNvuHANTb6uPwGZ14F5799qFae3B+6d8gaGLMt1xGGwq1elPxEpWkg3BZl5wG+mY3U6NodoFkk3RurBxYru6tckEErzaGdHVx0pMVX3NJEluMXcSq/Hmnx8N7T0mfx1LRlkl3Cku3VpRilTAmD6Ek/OeXUlHFpxG6krxytwg23N8X/ezx+YvHpyeXj88mweGD6A8crOduVwySyrEm50L7CDSn1/FXON+6qbkHa0QHRS2unxC4UrEH1t7ETH0ECl1bg1un2KucdGdEAWK3556I3LA1b7fhzwMil2Sd0aOu+YGL2f8ei6MLXpLeVaTX/HGahCXCkTcnuUetCs4yRbtq9ds/Tq+4RgNJiSionJFk3XljCYpKeS4VbY4TjpKqKtTi4lISQ+uC02gfFH944Ea9tfdjKUkV+aYfCtqmgSgQuoLQnr3k0N70jLPPsn4135Z83TRQpApdDSf4L8lrd58g1m0fh8VmfgRRwapuYHkikLzWZqWFK8mM971G4y53ArvZdBvURR/UhWlB3Yy//wJx+5GDiWbbsXhs7782d21bKbYGFOEkPK8/hmgGxyAVDVVTsHZBNs1Rh+cssq5zg1rInglLhCcvTq+hKqWTLbCnwvXN8MXHh/xnRlM9EPELYVj9IN827fpFWllJyGLyFscFJ0HJvFCnjGqTvHZ5HEKCKpS0RU2sQ3Ezq+jPpzStyAM51lbPUJKVW6J+mjX+7Ojwy84Q75VtNYPvTreaQZO9EPulpPE9a7Qtu1ZYxupmpPHttwx35v8nOnxksyAbSXxUTTRVfE0w++78/2fd1xdC5vya/s9txA6qu9P9E8go5QLVesbwXpfPzzb2akq/WUgHgxuayqHOfO7eURB40sSCdXrSvvnM14KUCtMmk8Q+QkbgJDM5bdtOBQgfCpv7QMb7PJlx1gNG+LtdYaw0v6kInp7tYBnjtTZ2pCj1lG3fj3uKnwoT6n/J1rZsq5J1//tXt5VDcy3wc1Jl8NQC0twYCXgasCytKS1LVrOt59brwRNLBBfNmNkIZi8vzi/g3LKx7Otez+Ob8rd/xq+WoIwDkC2BzIiPO3Fy/e9/VDf8+68a5r//Cnn1279mE/gh1Orehhco11duI+o8cOGpWN03nUmMUYQD0bWFQ5/QdI39U3kas96T86fB38h5cOQdzNao+goE4bMR8O4zd/8g7orHdFNS6kNATgJf7WDbcT9BQkt+6uZJeMm0isWhdrdJE/5nbZ3pHOtzVHCaU3ptqriXZdKpMC4XWFSb3VtypdGOgOeAO0vO2gffDf2/+jjtBdKNflllWy6Wmsq6UGpIW2FDtSVqMAFBAxhNQ5LFJN5ReIDcEm9fVLlldjvfjtz60UgswkFSN869cdCoIx4W5Dd52D3x0de//M9/AAAA//8=
// DO NOT EDIT
using System.Runtime.Serialization;
using System.Collections.Generic;


namespace PayPalCheckoutSdk.Orders
{
    /// <summary>
    /// The shipping details.
    /// </summary>
    [DataContract]
    public class ShippingDetail
    {
        /// <summary>
	    /// Required default constructor
		/// </summary>
        public ShippingDetail() {}

        /// <summary>
        /// The portable international postal address. Maps to [AddressValidationMetadata](https://github.com/googlei18n/libaddressinput/wiki/AddressValidationMetadata) and HTML 5.1 [Autofilling form controls: the autocomplete attribute](https://www.w3.org/TR/html51/sec-forms.html#autofilling-form-controls-the-autocomplete-attribute).
        /// </summary>
        [DataMember(Name="address", EmitDefaultValue = false)]
        public AddressPortable AddressPortable;

        /// <summary>
        /// The name of the party.
        /// </summary>
        [DataMember(Name="name", EmitDefaultValue = false)]
        public Name Name;

        /// <summary>
        /// An array of shipping options that the payee or merchant offers to the payer to ship or pick up their items
        /// </summary>
        [DataMember(Name="options", EmitDefaultValue = false)]
        public List<ShippingOption> Options;
    }
}


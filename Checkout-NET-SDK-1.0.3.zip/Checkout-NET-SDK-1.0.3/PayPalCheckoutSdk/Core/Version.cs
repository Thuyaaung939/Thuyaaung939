namespace PayPalCheckoutSdk.Core
{
    public class Version
    {
        public static string VERSION = "2.0.2";
    }
}
